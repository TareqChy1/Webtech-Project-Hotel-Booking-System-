<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Hotel Bandorbon</title>
	<link rel="stylesheet" href="hotel.css">
</head>
<body>
	<div class="container">
		<h1>Le Méridien Dhaka</h1>
		<div class="hotel-img">
			<div class="img-div">
				<img src="../images/places/dhaka/lm3.jpg" alt="">
			</div>
			<div class="hotel-det">
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam blanditiis consectetur dicta sapiente, maiores adipisci ut sit eius autem error quia quos similique praesentium optio possimus et mollitia suscipit temporibus.</p>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam blanditiis consectetur dicta sapiente, maiores adipisci ut sit eius autem error quia quos similique praesentium optio possimus et mollitia suscipit temporibus.</p>
		  </div>
			
		</div>


		<div class="hotel-img">
			<div class="hotel-det">
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam blanditiis consectetur dicta sapiente, maiores adipisci ut sit eius autem error quia quos similique praesentium optio possimus et mollitia suscipit temporibus.</p>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam blanditiis consectetur dicta sapiente, maiores adipisci ut sit eius autem error quia quos similique praesentium optio possimus et mollitia suscipit temporibus.</p>
		  </div>
			<div class="img-div">
				<img src="../images/places/dhaka/gh2.jpg" alt="">
			</div>
			
			
		</div>
	</div>


	<div class="container">
		<h1>RENAISSANCE DHAKA GULSHAN HOTEL</h1>
		<div class="hotel-img">
			<div class="img-div">
				<img src="../images/places/dhaka/gh5.jpg" alt="">
			</div>
			<div class="hotel-det">
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam blanditiis consectetur dicta sapiente, maiores adipisci ut sit eius autem error quia quos similique praesentium optio possimus et mollitia suscipit temporibus.</p>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam blanditiis consectetur dicta sapiente, maiores adipisci ut sit eius autem error quia quos similique praesentium optio possimus et mollitia suscipit temporibus.</p>
		  </div>
			
		</div>
		<br>


		<div class="hotel-img">
			<div class="hotel-det">
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam blanditiis consectetur dicta sapiente, maiores adipisci ut sit eius autem error quia quos similique praesentium optio possimus et mollitia suscipit temporibus.</p>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam blanditiis consectetur dicta sapiente, maiores adipisci ut sit eius autem error quia quos similique praesentium optio possimus et mollitia suscipit temporibus.</p>
		  </div>
			<div class="img-div">
				<img src="../images/places/dhaka/lm5.jpg" alt="">
			</div>
			
			
		</div>
	</div>
</body>
</html>