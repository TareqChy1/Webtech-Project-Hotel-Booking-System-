<html>
<head>
	<title>Reserve Confirmation</title>
</head>
<body style="background-color:lightslategray">
	<h1>Reservation Successful</h1>
	<br>
	<a href="home.php">Go to Home</a>
</body>
</html>