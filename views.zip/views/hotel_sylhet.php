<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Hotel Bandorbon</title>
	<link rel="stylesheet" href="hotel.css">
</head>
<body>
	<div class="container">
		<h1>Rose View Hotel</h1>
		<div class="hotel-img">
			<div class="img-div">
				<img src="../images/places/sylhet/sp2.jpg" alt="">
			</div>
			<div class="hotel-det">
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam blanditiis consectetur dicta sapiente, maiores adipisci ut sit eius autem error quia quos similique praesentium optio possimus et mollitia suscipit temporibus.</p>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam blanditiis consectetur dicta sapiente, maiores adipisci ut sit eius autem error quia quos similique praesentium optio possimus et mollitia suscipit temporibus.</p>
		  </div>
			
		</div>


		<div class="hotel-img">
			<div class="hotel-det">
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam blanditiis consectetur dicta sapiente, maiores adipisci ut sit eius autem error quia quos similique praesentium optio possimus et mollitia suscipit temporibus.</p>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam blanditiis consectetur dicta sapiente, maiores adipisci ut sit eius autem error quia quos similique praesentium optio possimus et mollitia suscipit temporibus.</p>
		  </div>
			<div class="img-div">
				<img src="../images/places/sylhet/rs2.jpg" alt="">
			</div>
			
			
		</div>
	</div>


	<div class="container">
		<h1>Hotel Star Pacific</h1>
		<div class="hotel-img">
			<div class="img-div">
				<img src="../images/places/sylhet/sp3.jpg" alt="">
			</div>
			<div class="hotel-det">
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam blanditiis consectetur dicta sapiente, maiores adipisci ut sit eius autem error quia quos similique praesentium optio possimus et mollitia suscipit temporibus.</p>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam blanditiis consectetur dicta sapiente, maiores adipisci ut sit eius autem error quia quos similique praesentium optio possimus et mollitia suscipit temporibus.</p>
		  </div>
			
		</div>
		<br>


		<div class="hotel-img">
			<div class="hotel-det">
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam blanditiis consectetur dicta sapiente, maiores adipisci ut sit eius autem error quia quos similique praesentium optio possimus et mollitia suscipit temporibus.</p>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam blanditiis consectetur dicta sapiente, maiores adipisci ut sit eius autem error quia quos similique praesentium optio possimus et mollitia suscipit temporibus.</p>
		  </div>
			<div class="img-div">
				<img src="../images/places/sylhet/sp4.jpg" alt="">
			</div>
			
			
		</div>
	</div>
</body>
</html>