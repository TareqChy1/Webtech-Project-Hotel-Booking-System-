<?php
	session_start();
  $_SESSION['active'] = false;
  $_SESSION['check'] = false;
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Get_Started</title>
    <link rel="stylesheet" href="style_get_started.css">
   
  </head>
  <body>
<div class="container">
  <span class="text1">Welcome in</span>
  <span class="text2">Hotel Bangla</span>
</div>
</div>
  <a href="home.php"><input type="submit" name="submit" class="text3" value="Get Started"> </a>
 <div>
  </body>
</html>