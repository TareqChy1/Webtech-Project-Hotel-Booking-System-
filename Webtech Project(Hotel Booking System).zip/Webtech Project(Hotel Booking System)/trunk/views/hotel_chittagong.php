<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Hotel Bandorbon</title>
	<link rel="stylesheet" href="hotel.css">
</head>
<body>
	<div class="container">
		<h1>The Radisson Blu Chattogram</h1>
		<div class="hotel-img">
			<div class="img-div">
				<img src="../images/places/chattogram/pc2.jpg" alt="">
			</div>
			<div class="hotel-det">
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam blanditiis consectetur dicta sapiente, maiores adipisci ut sit eius autem error quia quos similique praesentium optio possimus et mollitia suscipit temporibus.</p>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam blanditiis consectetur dicta sapiente, maiores adipisci ut sit eius autem error quia quos similique praesentium optio possimus et mollitia suscipit temporibus.</p>
		  </div>
			
		</div>


		<div class="hotel-img">
			<div class="hotel-det">
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam blanditiis consectetur dicta sapiente, maiores adipisci ut sit eius autem error quia quos similique praesentium optio possimus et mollitia suscipit temporibus.</p>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam blanditiis consectetur dicta sapiente, maiores adipisci ut sit eius autem error quia quos similique praesentium optio possimus et mollitia suscipit temporibus.</p>
		  </div>
			<div class="img-div">
				<img src="../images/places/chattogram/pc3.jpg" alt="">
			</div>
			
			
		</div>
	</div>


	<div class="container">
		<h1>The Peninsula Chittagong</h1>
		<div class="hotel-img">
			<div class="img-div">
				<img src="../images/places/chattogram/pc4.jpg" alt="">
			</div>
			<div class="hotel-det">
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam blanditiis consectetur dicta sapiente, maiores adipisci ut sit eius autem error quia quos similique praesentium optio possimus et mollitia suscipit temporibus.</p>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam blanditiis consectetur dicta sapiente, maiores adipisci ut sit eius autem error quia quos similique praesentium optio possimus et mollitia suscipit temporibus.</p>
		  </div>
			
		</div>
		<br>


		<div class="hotel-img">
			<div class="hotel-det">
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam blanditiis consectetur dicta sapiente, maiores adipisci ut sit eius autem error quia quos similique praesentium optio possimus et mollitia suscipit temporibus.</p>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsam blanditiis consectetur dicta sapiente, maiores adipisci ut sit eius autem error quia quos similique praesentium optio possimus et mollitia suscipit temporibus.</p>
		  </div>
			<div class="img-div">
				<img src="../images/places/chattogram/pc5.jpg" alt="">
			</div>
			
			
		</div>
	</div>
</body>
</html>